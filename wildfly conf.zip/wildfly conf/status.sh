#!/bin/bash
#//====================================================================
#// status.sh - Wildfly instance status script
#//
#// SYNOPSYS
#//   status.sh
#//
#// CHANGE HISTORY
#//   2016-06-17 v1.00 AL00385
#//
#//====================================================================

script_dir=$( cd $( dirname $0 ) && pwd )
source ${script_dir}/wildfly.conf

sudo systemctl status wildfly-${SERVER_NAME}

#!/bin/bash
#//====================================================================
#// stop.sh - Wildfly instance stop script
#//
#// SYNOPSYS
#//   stop.sh
#//
#// CHANGE HISTORY
#//   2016-04-28 v1.00 AL00206
#//   2016-05-13 v2.00 AL00243 Changed almost all
#//
#//====================================================================

script_dir=$( cd $( dirname $0 ) && pwd )
source ${script_dir}/wildfly.conf

sudo systemctl stop  wildfly-${SERVER_NAME}

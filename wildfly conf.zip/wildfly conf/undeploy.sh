#!/bin/bash
#//====================================================================
#// undeploy.sh - Wildfly instance undeploy script
#//
#// SYNOPSYS
#//   undeploy.sh appname
#//
#// CHANGE HISTORY
#//   2016-04-28 v1.00 AL00206
#//   2016-05-13 v2.00 AL00243 Changed almost all
#//
#//====================================================================

script_dir=$( cd $( dirname $0 ) && pwd )
source ${script_dir}/wildfly.conf

sudo -u wildfly $JBOSS_HOME_NEW/bin/jboss-cli.sh -c --controller=${CLI_CONTROLLER}:${CLI_PORT} --command="undeploy ${1}"

#!/bin/bash
#//====================================================================
#// start.sh - Wildfly instance start script
#//
#// SYNOPSYS
#//   start.sh
#//
#// CHANGE HISTORY
#//   2016-04-28 v1.00 
#//   2016-05-13 v2.00  Changed almost all
#//
#//====================================================================

script_dir=$( cd $( dirname $0 ) && pwd )
source ${script_dir}/wildfly.conf

sudo systemctl start wildfly-${SERVER_NAME}

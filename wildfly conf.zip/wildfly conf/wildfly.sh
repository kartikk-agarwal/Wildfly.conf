#!/bin/bash
script_dir=$( cd $( dirname $0 ) && pwd )
source ${script_dir}/wildfly.conf

export RUN_CONF
export JBOSS_BASE_DIR
export HEAP_MIN_MEMORY
export HEAP_MAX_MEMORY
export PERMGEN_SIZE
export JBOSS_MODULES_SYSTEM_PKGS
export JBOSS_OPTS

$JBOSS_HOME/bin/standalone.sh $JBOSS_OPTS
